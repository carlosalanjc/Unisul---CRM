from app import db
class Cliente(db.Model):
 id=db.Column(db.Integer,primary_key=True)
 nome=db.Column(db.String(150))
 telefone=db.Column(db.String(30))
 placa=db.Column(db.String(20))
 modelo=db.Column(db.String(120))
