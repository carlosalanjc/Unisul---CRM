from app import db
class Usuario(db.Model):
 id=db.Column(db.Integer,primary_key=True)
 nome=db.Column(db.String(120))
