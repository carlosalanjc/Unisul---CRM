from urllib.parse import quote

def gerar_link(numero, mensagem):
    numero = "".join(filter(str.isdigit, str(numero)))
    if not numero.startswith("55"):
        numero = "55" + numero
    return f"https://wa.me/{numero}?text={quote(mensagem)}"
