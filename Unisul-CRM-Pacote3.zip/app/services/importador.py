import pandas as pd

def importar_csv(file_storage):
    df = pd.read_csv(file_storage)
    # TODO: salvar no banco
    return len(df)
