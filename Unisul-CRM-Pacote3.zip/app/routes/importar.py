from flask import Blueprint, render_template, request, redirect, url_for, flash
import pandas as pd
from app.services.importador import importar_csv

bp = Blueprint("importar", __name__, url_prefix="/importar")

@bp.route("/", methods=["GET","POST"])
def index():
    if request.method == "POST":
        arquivo = request.files.get("arquivo")
        if arquivo:
            importar_csv(arquivo)
            flash("Importação concluída.")
            return redirect(url_for("importar.index"))
    return render_template("importar.html")
