from flask import Blueprint,render_template
bp=Blueprint('clientes',__name__,url_prefix='/clientes')
@bp.route('/')
def lista(): return render_template('clientes.html')
